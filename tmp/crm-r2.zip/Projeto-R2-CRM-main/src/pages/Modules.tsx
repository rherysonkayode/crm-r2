import React, { useState } from 'react';
import { 
  Users, Search, PlusCircle, MoreVertical, Mail, Phone, 
  Calendar as CalendarIcon, Clock, CheckCircle2, Circle,
  BarChart3, TrendingUp, DollarSign, Handshake, FileText, 
  FileSignature, Megaphone, MessageSquare, Settings, Filter,
  Send, Paperclip, Building2, User, Lock, Bell
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

export function Clients() {
  const [clients] = useState([
    { id: 1, name: 'João Silva', email: 'joao@email.com', phone: '(11) 99999-9999', status: 'Ativo', since: '2023-01-15' },
    { id: 2, name: 'Maria Oliveira', email: 'maria@email.com', phone: '(11) 88888-8888', status: 'Inativo', since: '2022-11-20' },
    { id: 3, name: 'Carlos Santos', email: 'carlos@email.com', phone: '(11) 77777-7777', status: 'Ativo', since: '2023-05-10' },
  ]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestão de Clientes</h1>
          <p className="text-slate-500">Gerencie sua carteira de clientes ativos e inativos.</p>
        </div>
        <button className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-700 transition-colors shadow-lg shadow-brand-600/20 flex items-center gap-2">
          <PlusCircle size={18} />
          Novo Cliente
        </button>
      </div>
      
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input type="text" placeholder="Buscar clientes..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-brand-500 outline-none" />
          </div>
          <button className="px-4 py-2 bg-slate-50 border border-slate-200 text-slate-600 rounded-xl text-sm font-medium hover:bg-slate-100 flex items-center gap-2">
            <Filter size={18} /> Filtros
          </button>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Cliente</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Contato</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Cliente desde</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {clients.map(client => (
              <tr key={client.id} className="hover:bg-slate-50">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-brand-100 text-brand-600 flex items-center justify-center font-bold">
                      {client.name.charAt(0)}
                    </div>
                    <span className="font-bold text-slate-900">{client.name}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-sm text-slate-600"><Mail size={14} /> {client.email}</div>
                    <div className="flex items-center gap-2 text-sm text-slate-600"><Phone size={14} /> {client.phone}</div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-bold ${client.status === 'Ativo' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                    {client.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-500">{new Date(client.since).toLocaleDateString()}</td>
                <td className="px-6 py-4 text-right">
                  <button className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"><MoreVertical size={18} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function Agenda() {
  const [tasks, setTasks] = useState([
    { id: 1, title: 'Visita AP001 com João', time: '10:00', date: 'Hoje', completed: false, type: 'Visita' },
    { id: 2, title: 'Ligar para Maria sobre contrato', time: '14:30', date: 'Hoje', completed: true, type: 'Ligação' },
    { id: 3, title: 'Reunião de alinhamento', time: '09:00', date: 'Amanhã', completed: false, type: 'Reunião' },
  ]);

  const toggleTask = (id: number) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Agenda e Tarefas</h1>
          <p className="text-slate-500">Organize seus compromissos e anotações do dia.</p>
        </div>
        <button className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-700 transition-colors shadow-lg shadow-brand-600/20 flex items-center gap-2">
          <PlusCircle size={18} />
          Nova Tarefa
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <h3 className="font-bold text-slate-900 text-lg">Próximas Tarefas</h3>
          {tasks.map(task => (
            <div key={task.id} className={`bg-white p-4 rounded-2xl border ${task.completed ? 'border-slate-200 opacity-60' : 'border-brand-200 shadow-sm'} flex items-center gap-4 transition-all`}>
              <button onClick={() => toggleTask(task.id)} className={`${task.completed ? 'text-emerald-500' : 'text-slate-300 hover:text-brand-500'}`}>
                {task.completed ? <CheckCircle2 size={24} /> : <Circle size={24} />}
              </button>
              <div className="flex-1">
                <h4 className={`font-bold ${task.completed ? 'text-slate-500 line-through' : 'text-slate-900'}`}>{task.title}</h4>
                <div className="flex items-center gap-4 mt-1 text-sm text-slate-500">
                  <span className="flex items-center gap-1"><CalendarIcon size={14} /> {task.date}</span>
                  <span className="flex items-center gap-1"><Clock size={14} /> {task.time}</span>
                  <span className="bg-slate-100 px-2 py-0.5 rounded-md text-xs font-medium">{task.type}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-fit">
          <h3 className="font-bold text-slate-900 text-lg mb-4">Anotações Rápidas</h3>
          <textarea 
            className="w-full h-48 p-4 bg-slate-50 border border-slate-200 rounded-xl resize-none focus:ring-2 focus:ring-brand-500 outline-none text-sm"
            placeholder="Escreva suas anotações aqui..."
          ></textarea>
          <button className="w-full mt-4 py-2 bg-slate-900 text-white rounded-xl font-medium hover:bg-slate-800">
            Salvar Anotação
          </button>
        </div>
      </div>
    </div>
  );
}

export function FollowUps() {
  const followups = [
    { id: 1, client: 'Pedro Santos', property: 'AP001', lastContact: '2 dias atrás', nextAction: 'Enviar proposta', status: 'Urgente' },
    { id: 2, client: 'Ana Costa', property: 'CA002', lastContact: '5 dias atrás', nextAction: 'Agendar visita', status: 'Pendente' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Follow-ups</h1>
        <p className="text-slate-500">Acompanhe as negociações em andamento e não perca vendas.</p>
      </div>
      <div className="grid gap-4">
        {followups.map(f => (
          <div key={f.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className={`w-2 h-12 rounded-full ${f.status === 'Urgente' ? 'bg-red-500' : 'bg-amber-500'}`}></div>
              <div>
                <h4 className="font-bold text-slate-900">{f.client} <span className="text-slate-400 font-normal text-sm">({f.property})</span></h4>
                <p className="text-sm text-slate-500 mt-1">Último contato: {f.lastContact} • Próxima ação: <span className="font-medium text-slate-700">{f.nextAction}</span></p>
              </div>
            </div>
            <button className="px-4 py-2 bg-brand-50 text-brand-600 rounded-xl text-sm font-bold hover:bg-brand-100">
              Registrar Contato
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Reports() {
  const data = [
    { name: 'Jan', vendas: 4000, leads: 2400 },
    { name: 'Fev', vendas: 3000, leads: 1398 },
    { name: 'Mar', vendas: 2000, leads: 9800 },
    { name: 'Abr', vendas: 2780, leads: 3908 },
    { name: 'Mai', vendas: 1890, leads: 4800 },
    { name: 'Jun', vendas: 2390, leads: 3800 },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Relatórios Estratégicos</h1>
        <p className="text-slate-500">Análise de desempenho e métricas da imobiliária.</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-900 mb-6">Vendas vs Leads (6 meses)</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip cursor={{fill: '#f8fafc'}} />
                <Bar dataKey="vendas" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                <Bar dataKey="leads" fill="#94a3b8" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-900 mb-6">Métricas Principais</h3>
          <div className="space-y-4">
            {[
              { label: 'Taxa de Conversão', value: '4.2%', icon: TrendingUp, color: 'text-emerald-500' },
              { label: 'Tempo Médio de Venda', value: '45 dias', icon: Clock, color: 'text-blue-500' },
              { label: 'Ticket Médio', value: 'R$ 650.000', icon: DollarSign, color: 'text-purple-500' },
            ].map(m => (
              <div key={m.label} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                <div className="flex items-center gap-3">
                  <m.icon size={20} className={m.color} />
                  <span className="font-medium text-slate-700">{m.label}</span>
                </div>
                <span className="font-bold text-slate-900 text-lg">{m.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function Partnerships() {
  const partners = [
    { id: 1, name: 'Construtora Alpha', type: 'Construtora', comission: '5%', status: 'Ativo' },
    { id: 2, name: 'Banco Beta', type: 'Correspondente', comission: '1%', status: 'Ativo' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Rede de Parcerias</h1>
          <p className="text-slate-500">Gerencie construtoras, captadores e correspondentes.</p>
        </div>
        <button className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-700">Novo Parceiro</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {partners.map(p => (
          <div key={p.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-500 mb-4">
              <Handshake size={24} />
            </div>
            <h3 className="font-bold text-slate-900 text-lg">{p.name}</h3>
            <p className="text-sm text-slate-500 mb-4">{p.type}</p>
            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <span className="text-sm font-medium text-slate-600">Comissão: <strong className="text-slate-900">{p.comission}</strong></span>
              <span className="px-2 py-1 bg-emerald-100 text-emerald-700 rounded-md text-xs font-bold">{p.status}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Commissions() {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Controle de Comissões</h1>
        <p className="text-slate-500">Acompanhe seus recebimentos e previsões.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <p className="text-sm text-slate-500 font-medium mb-1">A Receber (Mês)</p>
          <h3 className="text-3xl font-bold text-slate-900">R$ 15.400</h3>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <p className="text-sm text-slate-500 font-medium mb-1">Recebido (Mês)</p>
          <h3 className="text-3xl font-bold text-emerald-600">R$ 8.200</h3>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <p className="text-sm text-slate-500 font-medium mb-1">Total Anual</p>
          <h3 className="text-3xl font-bold text-brand-600">R$ 142.000</h3>
        </div>
      </div>
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Imóvel</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Valor Venda</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Comissão</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            <tr className="hover:bg-slate-50">
              <td className="px-6 py-4 font-medium text-slate-900">AP001 - Jardins</td>
              <td className="px-6 py-4 text-slate-600">R$ 750.000</td>
              <td className="px-6 py-4 font-bold text-slate-900">R$ 15.000</td>
              <td className="px-6 py-4"><span className="px-2 py-1 bg-amber-100 text-amber-700 rounded-md text-xs font-bold">A Receber</span></td>
            </tr>
            <tr className="hover:bg-slate-50">
              <td className="px-6 py-4 font-medium text-slate-900">CA002 - Alphaville</td>
              <td className="px-6 py-4 text-slate-600">R$ 1.200.000</td>
              <td className="px-6 py-4 font-bold text-slate-900">R$ 24.000</td>
              <td className="px-6 py-4"><span className="px-2 py-1 bg-emerald-100 text-emerald-700 rounded-md text-xs font-bold">Recebido</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function Proposals() {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Propostas Comerciais</h1>
          <p className="text-slate-500">Gerencie propostas enviadas e recebidas.</p>
        </div>
        <button className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-700">Nova Proposta</button>
      </div>
      <div className="grid gap-4">
        {[1, 2].map(i => (
          <div key={i} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center"><FileText size={20} /></div>
              <div>
                <h4 className="font-bold text-slate-900">Proposta de Compra - AP00{i}</h4>
                <p className="text-sm text-slate-500">Cliente: João Silva • Valor: R$ 720.000</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="px-3 py-1.5 bg-slate-100 text-slate-600 rounded-lg text-sm font-medium hover:bg-slate-200">Ver PDF</button>
              <button className="px-3 py-1.5 bg-emerald-50 text-emerald-600 rounded-lg text-sm font-medium hover:bg-emerald-100">Aprovar</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Contracts() {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestão de Contratos</h1>
          <p className="text-slate-500">Contratos de compra, venda e locação.</p>
        </div>
        <button className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-700">Gerar Contrato</button>
      </div>
      <div className="grid gap-4">
        {[1, 2].map(i => (
          <div key={i} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-purple-50 text-purple-600 rounded-xl flex items-center justify-center"><FileSignature size={20} /></div>
              <div>
                <h4 className="font-bold text-slate-900">Contrato de Locação - ST00{i}</h4>
                <p className="text-sm text-slate-500">Vencimento: 10/12/2024 • Status: Assinatura Pendente</p>
              </div>
            </div>
            <button className="px-3 py-1.5 bg-brand-50 text-brand-600 rounded-lg text-sm font-medium hover:bg-brand-100">Enviar para Assinatura</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Marketing() {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Ferramentas de Marketing</h1>
        <p className="text-slate-500">Crie campanhas e dispare mensagens para seus leads.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-green-100 text-green-600 rounded-xl flex items-center justify-center mb-4">
            <MessageSquare size={24} />
          </div>
          <h3 className="font-bold text-slate-900 text-lg mb-2">Disparo WhatsApp</h3>
          <p className="text-slate-500 text-sm mb-6">Envie mensagens em massa para leads de uma região específica.</p>
          <button className="w-full py-2 bg-green-500 text-white rounded-xl font-medium hover:bg-green-600">Criar Campanha</button>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-4">
            <Mail size={24} />
          </div>
          <h3 className="font-bold text-slate-900 text-lg mb-2">E-mail Marketing</h3>
          <p className="text-slate-500 text-sm mb-6">Crie newsletters com os imóveis da semana para sua base.</p>
          <button className="w-full py-2 bg-blue-500 text-white rounded-xl font-medium hover:bg-blue-600">Criar E-mail</button>
        </div>
      </div>
    </div>
  );
}

export function Messages() {
  return (
    <div className="h-[calc(100vh-8rem)] bg-white rounded-2xl border border-slate-200 shadow-sm flex overflow-hidden animate-in fade-in duration-500">
      <div className="w-80 border-r border-slate-200 flex flex-col">
        <div className="p-4 border-b border-slate-100">
          <input type="text" placeholder="Buscar conversa..." className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none" />
        </div>
        <div className="flex-1 overflow-y-auto">
          {[1, 2, 3].map(i => (
            <div key={i} className={`p-4 border-b border-slate-50 cursor-pointer hover:bg-slate-50 ${i === 1 ? 'bg-brand-50/50' : ''}`}>
              <div className="flex justify-between items-start mb-1">
                <h4 className="font-bold text-slate-900 text-sm">Cliente {i}</h4>
                <span className="text-[10px] text-slate-400">10:4{i}</span>
              </div>
              <p className="text-xs text-slate-500 truncate">Olá, gostaria de saber mais sobre o imóvel...</p>
            </div>
          ))}
        </div>
      </div>
      <div className="flex-1 flex flex-col">
        <div className="p-4 border-b border-slate-100 flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-200 rounded-full"></div>
          <div>
            <h4 className="font-bold text-slate-900">Cliente 1</h4>
            <p className="text-xs text-emerald-500">Online</p>
          </div>
        </div>
        <div className="flex-1 p-6 bg-slate-50 overflow-y-auto">
          <div className="flex flex-col gap-4">
            <div className="bg-white p-3 rounded-2xl rounded-tl-none border border-slate-200 max-w-[70%] self-start shadow-sm">
              <p className="text-sm text-slate-700">Olá, gostaria de saber mais sobre o imóvel AP001.</p>
            </div>
            <div className="bg-brand-600 p-3 rounded-2xl rounded-tr-none text-white max-w-[70%] self-end shadow-sm">
              <p className="text-sm">Olá! Claro, o AP001 é excelente. Gostaria de agendar uma visita?</p>
            </div>
          </div>
        </div>
        <div className="p-4 border-t border-slate-100 bg-white flex gap-2">
          <button className="p-3 text-slate-400 hover:bg-slate-100 rounded-xl"><Paperclip size={20} /></button>
          <input type="text" placeholder="Digite sua mensagem..." className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none" />
          <button className="p-3 bg-brand-600 text-white rounded-xl hover:bg-brand-700"><Send size={20} /></button>
        </div>
      </div>
    </div>
  );
}

export function SettingsPage() {
  const [activeTab, setActiveTab] = useState('Perfil');

  return (
    <div className="max-w-4xl space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Configurações</h1>
        <p className="text-slate-500">Gerencie as preferências da sua conta e sistema.</p>
      </div>
      
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="flex border-b border-slate-100">
          {['Perfil', 'Empresa', 'Notificações', 'Integrações'].map(tab => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-4 text-sm font-bold transition-colors ${
                activeTab === tab 
                  ? 'text-brand-600 border-b-2 border-brand-600' 
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
        
        <div className="p-8 space-y-8">
          {activeTab === 'Perfil' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              <div className="flex items-center gap-6">
                <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 border-2 border-dashed border-slate-300">
                  <User size={32} />
                </div>
                <div>
                  <button className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium hover:bg-slate-50 shadow-sm">Alterar Foto</button>
                  <p className="text-xs text-slate-500 mt-2">JPG, GIF ou PNG. Max 1MB.</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">Nome Completo</label>
                  <input type="text" defaultValue="Corretor Silva" className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">E-mail</label>
                  <input type="email" defaultValue="silva@imobr2.com" className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">Telefone</label>
                  <input type="text" defaultValue="(11) 99999-9999" className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">CRECI</label>
                  <input type="text" defaultValue="123456-F" className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'Empresa' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              <div className="flex items-center gap-6">
                <div className="w-24 h-24 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-400 border-2 border-dashed border-slate-300">
                  <Building2 size={32} />
                </div>
                <div>
                  <button className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium hover:bg-slate-50 shadow-sm">Alterar Logo</button>
                  <p className="text-xs text-slate-500 mt-2">JPG, GIF ou PNG. Max 2MB.</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">Nome da Imobiliária</label>
                  <input type="text" defaultValue="ImobR2" className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">CNPJ</label>
                  <input type="text" defaultValue="00.000.000/0001-00" className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
                <div className="space-y-2 col-span-2">
                  <label className="text-sm font-semibold text-slate-700">Endereço Completo</label>
                  <input type="text" defaultValue="Av. Paulista, 1000 - Bela Vista, São Paulo - SP" className="w-full px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-brand-500" />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'Notificações' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <h3 className="font-bold text-slate-900 mb-4">Preferências de Alertas</h3>
              
              {[
                { title: 'Novos Leads', desc: 'Receber alerta quando um novo lead for cadastrado.' },
                { title: 'Mensagens de Clientes', desc: 'Notificar sobre novas mensagens no chat.' },
                { title: 'Lembretes de Agenda', desc: 'Avisar 30 minutos antes de visitas e reuniões.' },
                { title: 'Atualizações de Imóveis', desc: 'Alertar sobre mudanças de preço ou status.' }
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{item.title}</h4>
                    <p className="text-xs text-slate-500 mt-1">{item.desc}</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-600"></div>
                  </label>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'Integrações' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <h3 className="font-bold text-slate-900 mb-4">Conectar Serviços</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { name: 'WhatsApp Business', status: 'Conectado', color: 'text-emerald-500', bg: 'bg-emerald-50' },
                  { name: 'Google Calendar', status: 'Conectar', color: 'text-slate-500', bg: 'bg-slate-100' },
                  { name: 'Facebook Ads', status: 'Conectar', color: 'text-slate-500', bg: 'bg-slate-100' },
                  { name: 'RD Station', status: 'Conectado', color: 'text-blue-500', bg: 'bg-blue-50' }
                ].map((item, i) => (
                  <div key={i} className="p-5 border border-slate-200 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${item.bg} ${item.color}`}>
                        <Lock size={20} />
                      </div>
                      <span className="font-bold text-slate-900">{item.name}</span>
                    </div>
                    <button className={`px-4 py-2 rounded-xl text-sm font-bold transition-colors ${
                      item.status === 'Conectado' 
                        ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' 
                        : 'bg-brand-50 text-brand-600 hover:bg-brand-100'
                    }`}>
                      {item.status}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <div className="pt-6 border-t border-slate-100 flex justify-end gap-3">
            <button className="px-6 py-2 bg-slate-100 text-slate-700 rounded-xl font-medium hover:bg-slate-200">Cancelar</button>
            <button className="px-6 py-2 bg-brand-600 text-white rounded-xl font-bold hover:bg-brand-700 shadow-lg shadow-brand-600/20">Salvar Alterações</button>
          </div>
        </div>
      </div>
    </div>
  );
}
