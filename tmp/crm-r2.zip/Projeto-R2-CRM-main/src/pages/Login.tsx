"use client";

import React from "react";
import { Auth } from '@supabase/auth-ui-react';
import { ThemeSupa } from '@supabase/auth-ui-shared';
import { supabase } from "../integrations/supabase/client";
import { motion } from "motion/react";

export default function Login() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }} 
        animate={{ opacity: 1, y: 0 }} 
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-brand-600 rounded-2xl flex items-center justify-center text-white font-bold text-2xl mx-auto mb-4 shadow-lg shadow-brand-600/20">R2</div>
          <h1 className="text-3xl font-bold text-slate-900">ImobR2 CRM</h1>
          <p className="text-slate-500 mt-2">Entre na sua conta SaaS</p>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xl">
          <Auth
            supabaseClient={supabase}
            providers={[]}
            appearance={{
              theme: ThemeSupa,
              variables: {
                default: {
                  colors: {
                    brand: '#0284c7',
                    brandAccent: '#0369a1',
                  },
                },
              },
              className: {
                button: 'rounded-xl font-bold py-3',
                input: 'rounded-xl bg-slate-50 border-slate-200',
              }
            }}
            localization={{
              variables: {
                sign_in: {
                  email_label: 'E-mail',
                  password_label: 'Senha',
                  button_label: 'Entrar',
                },
                sign_up: {
                  email_label: 'E-mail',
                  password_label: 'Senha',
                  button_label: 'Cadastrar',
                }
              }
            }}
            theme="light"
          />
        </div>

        <div className="text-center mt-8">
          <button 
            onClick={() => window.open('https://wa.me/r2tech', '_blank')} 
            className="text-slate-400 text-xs font-medium hover:text-brand-600 transition-colors"
          >
            Fale com o suporte R2 Tech
          </button>
        </div>
      </motion.div>
    </div>
  );
}