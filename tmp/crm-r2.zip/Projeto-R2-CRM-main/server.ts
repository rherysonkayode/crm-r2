import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";

const db = new Database("crm.db");

// Initialize Database with Multi-tenant support
db.exec(`
  CREATE TABLE IF NOT EXISTS companies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL, -- 'individual' or 'agency'
    plan TEXT DEFAULT 'starter', -- 'starter', 'pro', 'enterprise'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'broker', -- 'owner', 'admin', 'manager', 'broker'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id)
  );

  CREATE TABLE IF NOT EXISTS leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    broker_id INTEGER, -- Assigned broker
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    source TEXT,
    status TEXT DEFAULT 'Novo',
    interest TEXT,
    price_range TEXT,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id),
    FOREIGN KEY (broker_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS properties (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    broker_id INTEGER,
    code TEXT NOT NULL,
    title TEXT NOT NULL,
    type TEXT,
    purpose TEXT,
    price REAL,
    neighborhood TEXT,
    city TEXT,
    description TEXT,
    status TEXT DEFAULT 'Ativo',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id)
  );
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes with Multi-tenant filtering
  app.get("/api/dashboard/stats", (req, res) => {
    const companyId = req.query.companyId;
    const userId = req.query.userId;
    const role = req.query.role;

    let leadQuery = "SELECT COUNT(*) as count FROM leads WHERE company_id = ?";
    let propQuery = "SELECT COUNT(*) as count FROM properties WHERE company_id = ? AND status = 'Ativo'";
    
    // If broker, only see their own leads/props
    if (role === 'broker') {
      leadQuery += " AND broker_id = ?";
      propQuery += " AND broker_id = ?";
    }

    const totalLeads = db.prepare(leadQuery).get(companyId, role === 'broker' ? userId : undefined) as any;
    const activeProps = db.prepare(propQuery).get(companyId, role === 'broker' ? userId : undefined) as any;
    
    const leadsByStatus = db.prepare("SELECT status, COUNT(*) as count FROM leads WHERE company_id = ? GROUP BY status").all(companyId);
    const leadsBySource = db.prepare("SELECT source, COUNT(*) as count FROM leads WHERE company_id = ? GROUP BY source").all(companyId);
    
    res.json({
      totalLeads: totalLeads.count,
      activeProperties: activeProps.count,
      leadsByStatus,
      leadsBySource
    });
  });

  app.get("/api/leads", (req, res) => {
    const { companyId, userId, role } = req.query;
    let query = "SELECT * FROM leads WHERE company_id = ?";
    let params = [companyId];

    if (role === 'broker') {
      query += " AND broker_id = ?";
      params.push(userId as string);
    }

    const leads = db.prepare(query + " ORDER BY created_at DESC").all(...params);
    res.json(leads);
  });

  app.post("/api/auth/register", (req, res) => {
    const { name, email, password, type } = req.body;
    
    const companyInfo = db.prepare("INSERT INTO companies (name, type, plan) VALUES (?, ?, ?)").run(
      type === 'agency' ? name : `Individual - ${name}`,
      type === 'agency' ? 'agency' : 'individual',
      'starter'
    );
    
    const userInfo = db.prepare("INSERT INTO users (company_id, name, email, password, role) VALUES (?, ?, ?, ?, ?)").run(
      companyInfo.lastInsertRowid,
      name,
      email,
      password,
      'owner'
    );

    res.json({ 
      id: userInfo.lastInsertRowid, 
      company_id: companyInfo.lastInsertRowid,
      role: 'owner',
      type: type
    });
  });

  // Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();