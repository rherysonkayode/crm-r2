"use client";

import React, { useState, useEffect } from 'react';
import { DragDropContext, Droppable, DropResult } from '@hello-pangea/dnd';
import { PlusCircle, Search, Filter, LayoutGrid, List, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { supabase } from "../integrations/supabase/client";
import { useAuth } from '../hooks/useAuth';
import { cn, type Lead } from '../lib/utils';
import LeadCard from '../components/LeadCard';
import LeadDetailsModal from '../components/LeadDetailsModal';

const STAGES = ['Novo', 'Em contato', 'Visitou', 'Proposta enviada', 'Fechado', 'Perdido'];

export default function Leads({ onNewLead }: { onNewLead: () => void }) {
  const { profile } = useAuth();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'list' | 'funnel'>('funnel');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);

  useEffect(() => {
    if (profile) fetchLeads();
  }, [profile]);

  const fetchLeads = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) setLeads(data as any);
    setLoading(false);
  };

  const onDragEnd = async (result: DropResult) => {
    const { destination, source, draggableId } = result;
    if (!destination) return;
    if (destination.droppableId === source.droppableId && destination.index === source.index) return;

    const newStatus = destination.droppableId;
    const leadId = draggableId;

    // Optimistic update
    setLeads(leads.map(l => l.id.toString() === leadId ? { ...l, status: newStatus } : l));

    await supabase
      .from('leads')
      .update({ status: newStatus })
      .eq('id', leadId);
  };

  const filteredLeads = leads.filter(lead => 
    lead.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    lead.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) return <div className="h-full flex items-center justify-center"><Loader2 className="animate-spin text-brand-600" size={40} /></div>;

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestão de Leads</h1>
          <p className="text-slate-500">Acompanhe sua jornada de vendas em tempo real.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={onNewLead}
            className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-700 transition-colors shadow-lg shadow-brand-600/20 flex items-center gap-2"
          >
            <PlusCircle size={18} /> Novo Lead
          </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap gap-4 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Buscar por nome ou e-mail..." 
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-brand-500 transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="flex-1 min-h-0">
        <DragDropContext onDragEnd={onDragEnd}>
          <div className="flex gap-4 overflow-x-auto pb-4 h-full custom-scrollbar">
            {STAGES.map(stage => (
              <div key={stage} className="flex-shrink-0 w-80 flex flex-col">
                <h4 className="font-bold text-slate-900 text-sm mb-4 px-2 flex items-center gap-2">
                  {stage}
                  <span className="bg-slate-200/50 px-2 py-0.5 rounded-full text-[10px] text-slate-600">
                    {filteredLeads.filter(l => l.status === stage).length}
                  </span>
                </h4>
                <Droppable droppableId={stage}>
                  {(provided, snapshot) => (
                    <div
                      {...provided.droppableProps}
                      ref={provided.innerRef}
                      className={cn(
                        "flex-1 bg-slate-100/50 rounded-2xl p-3 border border-slate-200/50 overflow-y-auto custom-scrollbar transition-colors",
                        snapshot.isDraggingOver && "bg-brand-50/50 border-brand-200"
                      )}
                    >
                      {filteredLeads
                        .filter(l => l.status === stage)
                        .map((lead, index) => (
                          <LeadCard 
                            key={lead.id} 
                            lead={lead} 
                            index={index} 
                            onClick={(l) => setSelectedLead(l)} 
                          />
                        ))}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </div>
            ))}
          </div>
        </DragDropContext>
      </div>

      <AnimatePresence>
        {selectedLead && (
          <LeadDetailsModal 
            lead={selectedLead} 
            onClose={() => setSelectedLead(null)} 
            onUpdate={(updated) => setLeads(leads.map(l => l.id === updated.id ? updated : l))}
          />
        )}
      </AnimatePresence>
    </div>
  );
}