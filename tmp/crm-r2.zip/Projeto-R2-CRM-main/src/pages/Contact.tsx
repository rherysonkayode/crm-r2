import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">Entre em Contato</h1>
        <p className="text-lg text-slate-600">Estamos aqui para ajudar você a encontrar o imóvel dos seus sonhos ou tirar qualquer dúvida.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          {submitted ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="h-full flex flex-col items-center justify-center text-center py-12"
            >
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-6">
                <CheckCircle2 size={32} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Mensagem Enviada!</h2>
              <p className="text-slate-500">Obrigado pelo contato. Nossa equipe retornará em breve.</p>
              <button 
                onClick={() => setSubmitted(false)}
                className="mt-8 text-brand-600 font-semibold hover:underline"
              >
                Enviar outra mensagem
              </button>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">Nome Completo</label>
                  <input required type="text" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-brand-500 outline-none transition-all" placeholder="Seu nome" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">E-mail</label>
                  <input required type="email" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-brand-500 outline-none transition-all" placeholder="seu@email.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Assunto</label>
                <input required type="text" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-brand-500 outline-none transition-all" placeholder="Como podemos ajudar?" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Mensagem</label>
                <textarea required rows={4} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-brand-500 outline-none transition-all resize-none" placeholder="Sua mensagem..."></textarea>
              </div>
              <button type="submit" className="w-full py-4 bg-brand-600 text-white rounded-xl font-bold hover:bg-brand-700 transition-all shadow-lg shadow-brand-600/20 flex items-center justify-center gap-2">
                <Send size={20} />
                Enviar Mensagem
              </button>
            </form>
          )}
        </div>

        <div className="space-y-6">
          <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-xl">
            <h3 className="text-xl font-bold mb-6">Informações</h3>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-white/10 rounded-lg"><Phone size={20} /></div>
                <div>
                  <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">Telefone</p>
                  <p className="font-medium">(11) 99999-9999</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-2 bg-white/10 rounded-lg"><Mail size={20} /></div>
                <div>
                  <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">E-mail</p>
                  <p className="font-medium">contato@imobr2.com</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-2 bg-white/10 rounded-lg"><MapPin size={20} /></div>
                <div>
                  <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">Endereço</p>
                  <p className="font-medium text-sm">Av. Paulista, 1000 - Bela Vista, São Paulo - SP</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-brand-50 p-6 rounded-3xl border border-brand-100">
            <h4 className="font-bold text-brand-900 mb-2">Atendimento 24/7</h4>
            <p className="text-sm text-brand-700">Nossa equipe de suporte está disponível para ajudar você a qualquer momento.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
