"use client";

import React, { useState, useEffect } from 'react';
import { PlusCircle, Search, Filter, Building2, MapPin, DollarSign, Loader2, MoreVertical } from 'lucide-react';
import { motion } from 'motion/react';
import { cn, type Property } from '../lib/utils';

export default function Properties({ onNewProperty }: { onNewProperty: () => void }) {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchProperties();
  }, []);

  const fetchProperties = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/properties');
      const data = await res.json();
      setProperties(data);
    } finally {
      setLoading(false);
    }
  };

  const filteredProperties = properties.filter(p => 
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.neighborhood.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading && properties.length === 0) {
    return (
      <div className="h-full flex items-center justify-center">
        <Loader2 className="animate-spin text-brand-600" size={40} />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestão de Imóveis</h1>
          <p className="text-slate-500">Gerencie seu catálogo de imóveis para venda e locação.</p>
        </div>
        <button 
          onClick={onNewProperty}
          className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-700 transition-colors shadow-lg shadow-brand-600/20 flex items-center gap-2 w-fit"
        >
          <PlusCircle size={18} />
          Novo Imóvel
        </button>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap gap-4 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Buscar por título, bairro ou código..." 
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-brand-500 transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <button className="px-4 py-2 bg-slate-50 border border-slate-200 text-slate-600 rounded-xl text-sm font-medium hover:bg-slate-100 flex items-center gap-2">
          <Filter size={18} /> Filtros
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProperties.map((property) => (
          <motion.div 
            key={property.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition-all group"
          >
            <div className="relative h-48 bg-slate-100 overflow-hidden">
              <img 
                src={`https://picsum.photos/seed/prop${property.id}/400/300`} 
                alt={property.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute top-3 left-3 flex gap-2">
                <span className={cn(
                  "px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider shadow-sm",
                  property.purpose === 'Venda' ? "bg-brand-600 text-white" : "bg-emerald-500 text-white"
                )}>
                  {property.purpose}
                </span>
                <span className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-[10px] font-bold text-slate-700 shadow-sm">
                  {property.type}
                </span>
              </div>
              <button className="absolute top-3 right-3 p-1.5 bg-white/90 backdrop-blur-sm rounded-lg text-slate-400 hover:text-slate-600 shadow-sm">
                <MoreVertical size={16} />
              </button>
            </div>
            
            <div className="p-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold text-brand-600 uppercase tracking-widest">{property.code}</span>
                <span className="text-[10px] font-medium text-slate-400">{new Date(property.created_at).toLocaleDateString()}</span>
              </div>
              <h3 className="font-bold text-slate-900 mb-2 line-clamp-1">{property.title}</h3>
              
              <div className="flex items-center gap-1 text-slate-500 text-xs mb-4">
                <MapPin size={14} />
                <span className="truncate">{property.neighborhood}, {property.city}</span>
              </div>
              
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-1 text-brand-600 font-bold">
                  <span className="text-sm">R$</span>
                  <span className="text-lg">
                    {new Intl.NumberFormat('pt-BR').format(property.price)}
                  </span>
                </div>
                <span className={cn(
                  "px-2 py-0.5 rounded-full text-[10px] font-bold",
                  property.status === 'Ativo' ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600"
                )}>
                  {property.status}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredProperties.length === 0 && (
        <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-200">
          <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <Building2 className="text-slate-300" size={32} />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Nenhum imóvel encontrado</h3>
          <p className="text-slate-500">Tente ajustar seus filtros ou cadastrar um novo imóvel.</p>
        </div>
      )}
    </div>
  );
}