import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, Users, UserCheck, Building2, Calendar, 
  PhoneCall, BarChart3, Handshake, DollarSign, FileText, 
  FileSignature, Megaphone, MessageSquare, Settings, Mail, 
  PlusCircle, Menu, X, Search, Bell, LogOut, Loader2, Users2
} from 'lucide-react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from './hooks/useAuth';
import { cn } from './lib/utils';

// Pages
import Dashboard from './components/Dashboard';
import Leads from './pages/Leads';
import Properties from './pages/Properties';
import Login from './pages/Login';
import { Clients, Agenda, FollowUps, Reports, Partnerships, Commissions, Proposals, Contracts, Marketing, Messages, SettingsPage } from './pages/Modules';

const Sidebar = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  const location = useLocation();
  const { user, logout } = useAuth();

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', to: '/' },
    { icon: Users, label: 'Leads', to: '/leads' },
    { icon: Building2, label: 'Imóveis', to: '/imoveis' },
    { icon: UserCheck, label: 'Clientes', to: '/clientes' },
    { icon: Calendar, label: 'Agenda', to: '/agenda' },
    { icon: PhoneCall, label: 'Follow-ups', to: '/follow-ups' },
    // Apenas para Imobiliárias
    ...(user?.company_type === 'agency' ? [
      { icon: Users2, label: 'Equipe', to: '/equipe' },
      { icon: BarChart3, label: 'Relatórios', to: '/relatorios' },
      { icon: DollarSign, label: 'Financeiro', to: '/financeiro' },
    ] : []),
    { icon: MessageSquare, label: 'Mensagens', to: '/mensagens' },
    { icon: Settings, label: 'Configurações', to: '/configuracoes' },
  ];

  return (
    <>
      <AnimatePresence>{isOpen && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] lg:hidden" />}</AnimatePresence>
      <aside className={cn("fixed inset-y-0 left-0 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-300 z-[70] lg:translate-x-0 lg:static lg:h-screen", isOpen ? "translate-x-0" : "-translate-x-full")}>
        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center text-white font-bold">R2</div>
            <span className="font-bold text-xl tracking-tight text-slate-900">ImobR2</span>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 lg:hidden"><X size={20} /></button>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1 custom-scrollbar">
          {menuItems.map((item) => (
            <Link key={item.to} to={item.to} onClick={() => window.innerWidth < 1024 && onClose()} className={cn("flex items-center gap-3 px-4 py-3 rounded-xl transition-all", location.pathname === item.to ? "bg-brand-600 text-white shadow-lg shadow-brand-600/20" : "text-slate-500 hover:bg-slate-100")}>
              <item.icon size={20} />
              <span className="font-medium text-sm">{item.label}</span>
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden shrink-0">
              <img src={`https://picsum.photos/seed/${user?.id}/100/100`} alt="Avatar" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-900 truncate">{user?.name}</p>
              <p className="text-xs text-slate-500 truncate uppercase">{user?.role}</p>
            </div>
            <button onClick={logout} className="p-2 text-slate-400 hover:text-red-500"><LogOut size={18} /></button>
          </div>
        </div>
      </aside>
    </>
  );
};

export default function App() {
  const { user, loading } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  if (loading) return <div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin text-brand-600" size={40} /></div>;

  return (
    <Router>
      <Routes>
        <Route path="/login" element={user ? <Navigate to="/" /> : <Login />} />
        <Route path="/*" element={
          !user ? <Navigate to="/login" /> : (
            <div className="flex min-h-screen bg-slate-50">
              <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
              <div className="flex-1 flex flex-col min-w-0">
                <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8">
                  <button onClick={() => setIsSidebarOpen(true)} className="p-2 lg:hidden"><Menu size={20} /></button>
                  <div className="flex-1 max-w-xl mx-4 hidden sm:block">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input type="text" placeholder="Pesquisar..." className="w-full pl-10 pr-4 py-2 bg-slate-100 rounded-xl text-sm outline-none" />
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-xl relative"><Bell size={20} /></button>
                    <button className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium flex items-center gap-2">
                      <PlusCircle size={18} /> <span className="hidden sm:inline">Novo Registro</span>
                    </button>
                  </div>
                </header>
                <main className="flex-1 p-4 lg:p-8 overflow-y-auto">
                  <Routes>
                    <Route path="/" element={<Dashboard />} />
                    <Route path="/leads" element={<Leads onNewLead={() => {}} />} />
                    <Route path="/imoveis" element={<Properties onNewProperty={() => {}} />} />
                    <Route path="/clientes" element={<Clients />} />
                    <Route path="/agenda" element={<Agenda />} />
                    <Route path="/follow-ups" element={<FollowUps />} />
                    <Route path="/relatorios" element={<Reports />} />
                    <Route path="/parcerias" element={<Partnerships />} />
                    <Route path="/comissoes" element={<Commissions />} />
                    <Route path="/propostas" element={<Proposals />} />
                    <Route path="/contratos" element={<Contracts />} />
                    <Route path="/marketing" element={<Marketing />} />
                    <Route path="/mensagens" element={<Messages />} />
                    <Route path="/configuracoes" element={<SettingsPage />} />
                  </Routes>
                </main>
              </div>
            </div>
          )
        } />
      </Routes>
    </Router>
  );
}