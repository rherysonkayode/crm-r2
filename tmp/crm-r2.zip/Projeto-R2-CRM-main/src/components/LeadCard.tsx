"use client";

import React from 'react';
import { Draggable } from '@hello-pangea/dnd';
import { ChevronRight, Mail, Phone } from 'lucide-react';
import { motion } from 'motion/react';
import { cn, type Lead } from '../lib/utils';

interface LeadCardProps {
  lead: Lead;
  index: number;
  onClick: (lead: Lead) => void;
}

export default function LeadCard({ lead, index, onClick }: LeadCardProps) {
  return (
    <Draggable draggableId={lead.id.toString()} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          className={cn(
            "bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all cursor-grab active:cursor-grabbing mb-3",
            snapshot.isDragging && "shadow-xl ring-2 ring-brand-500/20 border-brand-500"
          )}
          onClick={() => onClick(lead)}
        >
          <div className="flex justify-between items-start mb-2">
            <span className={cn(
              "text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full",
              lead.interest === 'Compra' ? "bg-blue-50 text-blue-600" : "bg-purple-50 text-purple-600"
            )}>
              {lead.interest}
            </span>
            <button className="text-slate-400 hover:text-slate-600">
              <ChevronRight size={14} />
            </button>
          </div>
          
          <h5 className="font-bold text-slate-900 text-sm mb-1">{lead.name}</h5>
          <p className="text-xs text-slate-500 mb-3">{lead.source}</p>
          
          <div className="flex items-center gap-3 text-slate-400">
            {lead.email && <Mail size={14} className="hover:text-brand-600 transition-colors" />}
            {lead.phone && <Phone size={14} className="hover:text-brand-600 transition-colors" />}
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
            <div className="flex -space-x-2">
              <div className="w-6 h-6 rounded-full border-2 border-white bg-slate-200 overflow-hidden">
                <img src={`https://picsum.photos/seed/lead${lead.id}/50/50`} alt="" referrerPolicy="no-referrer" />
              </div>
            </div>
            <span className="text-[10px] text-slate-400 font-medium">
              {new Date(lead.created_at).toLocaleDateString()}
            </span>
          </div>
        </div>
      )}
    </Draggable>
  );
}