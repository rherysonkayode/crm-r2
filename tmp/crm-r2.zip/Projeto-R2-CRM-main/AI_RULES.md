# AI Rules for ImobR2 CRM

This document outlines the architectural patterns, coding standards, and project-specific rules for the ImobR2 CRM application.

## Tech Stack
- **Frontend**: React 18+, TypeScript, Vite.
- **Styling**: Tailwind CSS (Utility-first).
- **Icons**: Lucide React.
- **Animations**: Framer Motion (`motion/react`).
- **Charts**: Recharts.
- **Routing**: React Router DOM v6.

## Project Structure
- `/src/App.tsx`: Central hub containing the main layout (Sidebar, Topbar), routing logic, and core page components (Leads, Properties).
- `/src/pages/Modules.tsx`: Shared file containing specialized modules (Clients, Agenda, Follow-ups, Reports, etc.).
- `/src/pages/Contact.tsx` & `/src/pages/Advertise.tsx`: Standalone page components.
- `/src/lib/utils.ts`: Global TypeScript interfaces (Lead, Property, Notification, DashboardStats) and utility functions.
- `/src/index.css`: Tailwind CSS entry point and global theme overrides.

## Coding Standards
- **Functional Components**: Use functional components with hooks exclusively.
- **Type Safety**: Maintain strict TypeScript typing. Define shared interfaces in `src/lib/utils.ts`.
- **Styling**: Use Tailwind CSS classes. Avoid inline styles or external CSS files.
- **Animations**: Use `AnimatePresence` and `motion` for all transitions, modals, and dropdowns.
- **Icons**: Always use `lucide-react`.

## Specific Rules & Patterns

### 1. Branding
- The application name is **ImobR2**.
- Primary brand color is `brand-600` (defined in Tailwind theme).
- Logo is represented by a rounded-lg div with "R2" text.

### 2. Navigation & Layout
- **Sidebar**: Collapsible. Contains main navigation and a Logout button at the bottom.
- **Topbar**: Contains Search, Notifications (with unread indicator), and "Novo Registro" dropdown.
- **Modals**: Use the custom `Modal` component in `App.tsx` for consistent look and feel.

### 3. State Management
- Use `useState` for local component state.
- For cross-page data refreshing (e.g., after adding a new lead), use the `refreshKey` pattern implemented in `App.tsx`.

### 4. API & Data
- Frontend communicates with `/api/*` endpoints.
- Ensure all `fetch` calls handle loading states and refresh the UI upon success.
- Use `Intl.NumberFormat` for currency (BRL) and `toLocaleDateString` for dates.

### 5. UI/UX
- **Responsiveness**: Design for all screen sizes using Tailwind's `md:`, `lg:`, etc.
- **Feedback**: Provide visual feedback for actions (hover states, loading indicators on buttons).
- **Empty States**: Always provide a fallback UI when lists or search results are empty.

## Prohibited Patterns
- **Do NOT** use `key` as a prop in custom components (React reserved word).
- **Do NOT** create new CSS files.
- **Do NOT** use `any` types where an interface can be defined.
- **Do NOT** rename the app from ImobR2.
