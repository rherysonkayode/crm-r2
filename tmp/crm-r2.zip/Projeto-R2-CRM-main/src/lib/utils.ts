import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export interface Lead {
  id: number;
  name: string;
  email: string;
  phone: string;
  source: string;
  status: string;
  interest: string;
  price_range: string;
  notes?: string;
  created_at: string;
}

export interface Property {
  id: number;
  code: string;
  title: string;
  type: string;
  purpose: string;
  price: number;
  neighborhood: string;
  city: string;
  description: string;
  status: string;
  created_at: string;
}

export interface DashboardStats {
  totalLeads: number;
  activeProperties: number;
  leadsByStatus: { status: string; count: number }[];
  leadsBySource: { source: string; count: number }[];
}

export interface Notification {
  id: number;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'lead' | 'property' | 'task';
}